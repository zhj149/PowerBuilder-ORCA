The test application located in files orca_test.pbl and orca_test2.pbl. 
It is necessary to open it in PB environment and make workable. The application 
is made in PB 9. After that it is possible to start the test with a command:

	 perl test.pl

The result should be as follows:

1..33
ok 1
Using: C:\Program Files\Sybase\Shared\PowerBuilder\pborc90.dll
ok 2
PowerBuilder version 9.0
ok 3
ok 4
ok 5
ok 6
ok 7
ok 8
ok 9
ok 10
ok 11
ok 12
ok 13
ok 14
ok 15
ok 16
ok 17
ok 18
ok 19
ok 20
ok 21
ok 22
ok 23
ok 24
ok 25
ok 26
ok 27
ok 28
ok 29
ok 30
ok 31
ok 32
ok 33
ok 34
ok 35
